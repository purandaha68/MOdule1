package com.cg.demo;

public interface DemoInterface {

	public String sayhi();
	
}
