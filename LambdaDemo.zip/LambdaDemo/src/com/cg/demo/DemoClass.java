package com.cg.demo;

public class DemoClass implements DemoInterface
{
	 
   public String sayhi() {
	return "Heello";
} 
	
}
