import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.demo.Calculator;


public class MyCalculator {

	@Test
	public void test() {
         
		Calculator cal = new Calculator();
		assertEquals(4,cal.add(2,2));
	
	}

}
