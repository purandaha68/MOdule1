package com.cg.demo;
import java.util.function.*;

@FunctionalInterface
interface Calculate{
	
	int findMin(int a, int b);
}



public class DemoMain 
{

	public static void main(String[] args) 
	{
//
//		DemoInterface demo = new DemoClass()
//		{
//		    @Override
//			public String sayhi()
//			{
//				return " ";
//			}
//		};	
		
		DemoInterface demo=()->"Hello Lambda";
		//Lambda can only be implemented when there is only one abstract method in the interface
		//Functional interface
		System.out.println(demo.sayhi());
		
		Calculate c1=(n1,n2)->n1>n2?n2:n1;
		System.out.println(c1.findMin(40,35));
		
		Supplier<Integer> getRandom=()->(int)(Math.random()*10);
		System.out.println(getRandom.get());
		
		Consumer<String> myconsumer =(str) -> System.out.println(str+"India");
		myconsumer.accept("Capgemini");
		
		Predicate<String> checklength1 = (str) -> str.length()>5;
		Predicate<String> checklength2 = (str) -> str.length()<15;
		System.out.println(checklength1.test("Hello"));
		System.out.println(checklength2.test("World"));
		
		
		
		
		
	}	 
}
