
public class ArrayIndexOOBDemo {

	public static void main(String[] args) {
		
		int arr[] = {10,20,30};
		System.out.println("Elements of the array:");
		for (int i = 0; i <= arr.length; i++) //Exception 
		{
			System.out.println(arr[i]);
		}
		System.out.println("Array output");
	}
	
	void method(){
		ArrayIndexOOBDemo a =new ArrayIndexOOBDemo();
		System.out.println("method");
	}

}
