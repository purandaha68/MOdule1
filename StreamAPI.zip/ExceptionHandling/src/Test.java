
public class Test {

	static ArrayIndexOOBDemo a;
	
	public static void main(String[] args) {
		ArrayIndexOOBDemo a =new ArrayIndexOOBDemo();
		//Test a = new Test();
        Test.a.method(); // we did not created instance of a
	       
           
	}

}
