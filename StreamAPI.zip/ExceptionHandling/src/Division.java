import java.util.Scanner;

// Arithmetic Exception 
// Exception while dividing 2 numbers

public class Division {

	public static void main(String[] args) {

		int a,b,c;
		System.out.println("enter two integers: ");
		Scanner sc = new Scanner(System.in);
		a=sc.nextInt();
		b=sc.nextInt();
		c=a/b;
		System.out.println("result"+c);
		System.out.println("More code can go here");
		
	}

}
