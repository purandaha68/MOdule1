
public class StringParser {

	// Number format exception
	
	public static void main(String[] args) {

	
		String s1 = "2000";
		int i1 = Integer.parseInt(s1);
		System.out.println(i1);
		
		String s = "abcd";  // This is an exception 
		int i = Integer.parseInt(s);
		System.out.println(i);
		
	
		
	}

}
