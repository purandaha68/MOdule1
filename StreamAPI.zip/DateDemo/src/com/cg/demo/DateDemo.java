package com.cg.demo;

import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DateDemo {
	

	

	public static void main(String[] args) {
//
//		Instant currenttime = Instant.now();
//		System.out.println(currenttime);
//		System.out.println(currenttime.getEpochSecond());
//		
		Scanner sc = new Scanner(System.in);  
		
		LocalDate today = LocalDate.now();//getting object of localdate
		System.out.println(today);
		System.out.println(today.getDayOfYear());
		System.out.println(today.plusDays(1));
		System.out.println(today.minusDays(2));
		
		LocalDate myBday = LocalDate.of(1996, 06, 24);
		System.out.println(myBday);
		
		Period age = Period.between(myBday,today);
		System.out.println(age.getYears()+"Years "+age.getMonths()+"Months "+age.getDays()+" days");
		
		System.out.println("Enter date in dd/mm/yyyy format: ");
		String dateStr1 = sc.next();
		
		DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
//		System.out.println("Enter date in dd/mm/yyyy format: ");
//		String dateStr2 = sc.next();
//		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		
		LocalDate mydate1 = LocalDate.parse(dateStr1, formatter1);
//	    LocalDate mydate2 = LocalDate.parse(dateStr2, formatter2);
		System.out.println(mydate1);
//		System.out.println(mydate2);
		
		
		ZonedDateTime ztime= ZonedDateTime.now();
		System.out.println(ztime);
		
		ZonedDateTime newztime = ztime.withZoneSameLocal(ZoneId.of("US/Hawaii"));// converts with current timezone
		System.out.println(newztime);
		
		System.out.println(ztime.withZoneSameInstant(ZoneId.of("US/Hawaii")));// It takes time of US and converts timezone
		
		
	}

}
