package com.cg.pl;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entities.Student;

public class Main {

	
	public static void main(String[] args) {
		
	  EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");	
	  EntityManager em = emf.createEntityManager(); 
	  
	  
	  Student student = new Student();
	  student.setRollno(1);
	  student.setName("Sai");
	  student.setTotalMarks(80);
	  student.setAddress("Vijayawada");
	  
	  student.setRollno(2);
	  student.setName("vinay");
	  student.setTotalMarks(50);
	  student.setAddress("Pune");
	 
	  student.setRollno(3);
	  student.setName("mani");
	  student.setTotalMarks(30);
	  student.setAddress("Mumbai");
	  
	  em.getTransaction().begin();
	  em.persist(student);
	  em.flush();
	  em.getTransaction().commit();
	  System.out.println("1 row added to DB");
	  
	  
//	  em.getTransaction().begin();
//	  Student stud;
//	  stud = em.find(Student.class, 1);
	  
//	  if(stud!=null){
//		  
//	  em.remove(stud);
//	  em.getTransaction().commit();
//	  System.out.println("Record Deleted");
//	  
//	  }
//	  else{
//		  System.out.println("entity does not exist");
//	  }
	}
	
	
	
}
