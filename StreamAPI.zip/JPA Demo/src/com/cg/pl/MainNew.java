package com.cg.pl;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entities.Student;

public class MainNew {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");	
		  EntityManager em = emf.createEntityManager(); 
		  

//		  Student s1 = em.find(Student.class, 1);
//		  Student s2 = em.find(Student.class, 2);
//		  Student s3 = em.find(Student.class, 3);
//		
//		  System.out.println(s1.getName());
//		  System.out.println(s1.getAddress());
//		  System.out.println(s1.getTotalMarks());
//		  
//		  System.out.println();
//		  
//		  System.out.println(s2.getName());
//		  System.out.println(s2.getAddress());
//		  System.out.println(s2.getTotalMarks());
//		  
//		  System.out.println(s3.getName());
//		  System.out.println(s3.getAddress());
//		  System.out.println(s3.getTotalMarks());
		  
	
////////// Method to delete the record		  
//		  em.getTransaction().begin();
//		  Student stud;
//		  stud = em.find(Student.class, 1);
//		  
//		  if(stud!=null){
//			  
//		  em.remove(stud);
//		  em.getTransaction().commit();
//		  System.out.println("Record Deleted");
//		  
//		  }
//		  else{
//			  System.out.println("entity does not exist");
//		  }
		  
///////// Method to update the record		  
		  em.getTransaction().begin();
		  Student s;
		  s = em.find(Student.class, 2);
		  s.setAddress("Vizag");
		  s.setName("purandhar");
		  em.merge(s);
		  em.getTransaction().commit();
		  System.out.println("Record Updated");
		  
		  
		}
		  
	}

 
