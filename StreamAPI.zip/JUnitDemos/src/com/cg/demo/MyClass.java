package com.cg.demo;

public class MyClass {

	
	public  String sayHello()
	{
		 
		return "Hello World";
		 
	}
	
	public static void main(String[] args) {
//		MyClass m = new MyClass();
//		System.out.println(m.sayHello());
		 
	}

}
