package com.cg.demo;

import static org.junit.Assert.*;

import org.junit.Test;


public class TestMyClass {

	@Test
	public void test() {
		
		MyClass obj = new MyClass();
		obj.sayHello();
		assertEquals("Hello World", obj.sayHello());
		//assertEquals("Sai", obj.sayHello());
		//assertEquals("Hello sai", obj.sayHello());
		 
	}

}
