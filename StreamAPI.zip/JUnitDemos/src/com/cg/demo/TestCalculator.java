package com.cg.demo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class TestCalculator {
	
	Calculator cal;
	@Before // It will work before whole code works
	public void before()
	{
		cal = new Calculator();
		System.out.println("Before method invoked");
	}

	@Test
	public void testAdd() {
		 Calculator cal = new Calculator();
		 assertEquals(4, cal.add(2, 2));
	}
	
	@Test
	public void testSubtract() {
		 Calculator cal = new Calculator();
		 assertEquals(0, cal.subtract(2, 2));
	}
	@Ignore
	@Test
	public void testMultiply() {
		 Calculator cal = new Calculator();
		 assertEquals(4, cal.multiply(2, 2));
	}
	
	//@Test(expected = ArithmeticException.class)// Testing exception
	
	@Test(expected = ArithmeticException.class)
	public void testDivide() {
		 Calculator cal = new Calculator();
		 assertEquals(0, cal.divide(2, 0));
	}

}
