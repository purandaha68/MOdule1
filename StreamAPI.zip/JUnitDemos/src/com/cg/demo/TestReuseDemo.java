package com.cg.demo;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runners.Parameterized;
import org.junit.runner.RunWith;

@RunWith(Parameterized.class)



public class TestReuseDemo {
	@Parameterized.Parameters
    public static Collection<Object[]>data()
    {
	      return Arrays.asList(new Object[][]{{-2,2,2},{0,0,0,},{1,1,2},{2,2,4},{3,6,9}});
    }
    
    private int input1;
    private int input2;
    private int expected;
    
    public TestReuseDemo(int input1, int input2, int expected)
    {
    	this.input1 = input1;
    	this.input2 = input2;
    	this.expected = expected;
    }  
    @Test
    public void test()
    {
    	Calculator cal = new Calculator();
    	assertEquals(expected, cal.add(input1, input2));
    	
    }
    
}
