package com.cg.demo;

public class Emp {
	
	private int empno;
	private String name;
	private int age;
	private double salary;
	private String dept;
	
	 
	public Emp(int empno, String name, int age, double salary, String dept) {
		super();
		this.empno = empno;
		this.name = name;
		this.age = age;
		this.salary = salary;
		this.dept = dept;
	}




	public int getEmpno() {
		return empno;
	}




	public void setEmpno(int empno) {
		this.empno = empno;
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public int getAge() {
		return age;
	}




	public void setAge(int age) {
		this.age = age;
	}




	public double getSalary() {
		return salary;
	}




	public void setSalary(double salary) {
		this.salary = salary;
	}




	public String getDept() {
		return dept;
	}




	public void setDept(String dept) {
		this.dept = dept;
	}




	@Override
	public String toString() {
		return "Emp [empno=" + empno + ", name=" + name + ", age=" + age
				+ ", salary=" + salary + ", dept=" + dept + "]";
	}
	
	
	

}
