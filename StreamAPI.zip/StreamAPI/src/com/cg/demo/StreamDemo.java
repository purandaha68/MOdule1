package com.cg.demo;

import java.util.Arrays;
import java.util.Optional;
import java.util.stream.Stream;

public class StreamDemo {

	public static void main(String[] args) {

		String friends[] = {"Amit","Smith","Naveen","Purwa","Anu"};
		System.out.println(Arrays.stream(friends).count());
		
		System.out.println(Arrays.stream(friends).filter((str)->str.length()<5).count());
		System.out.println(Arrays.stream(friends).filter((str)->str.contains("m")).count());
		
	Arrays.stream(friends).filter((str)->str.contains("m")).forEach(System.out::println);
	
	Arrays.stream(friends).map((str)->str.length()).forEach(System.out::println);

	Optional<String> result = Arrays.stream(friends).reduce((s1,s2)-> s1.concat(s2));	
		
	System.out.println(result.get());
	
	System.out.println(Stream.of(10,20,30).reduce((n1,n2)->n1+n2).get());
	System.out.println(Stream.of(10,20,30).max((n1,n2)->n1-n2).get());
	System.out.println(Stream.of(10,20,30).min((n1,n2)->n1-n2).get());
	}

}
