package com.cg.demo;

import java.util.ArrayList;
import java.util.List;

public class StreamDemo1 {

	public static void main(String[] args) {

		List<Emp> mylist = new ArrayList<>();
		mylist.add(new Emp(101, "Amit", 30, 4000,"HR"));
		mylist.add(new Emp(101, "Anita", 35, 5000,"DEV"));
		mylist.add(new Emp(101, "Ashish", 30, 3000,"HR"));
		mylist.add(new Emp(101, "Smith", 40, 4000,"TR"));
	    mylist.add(new Emp(101, "Manoj", 35, 4000,"HR"));
	
	mylist.stream().filter((emp)->emp.getAge()>30).forEach(System.out::println);
	
	System.out.println("Senior most:"+ mylist.stream().max((emp,emp1)->emp.getAge()-emp1.getAge()).get()); 
	
	System.out.println("Working in:"+ mylist.stream().max((emp,emp1)->emp.getAge()-emp1.getAge()).get()); 

	}

}
