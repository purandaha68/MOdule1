package com.cg.demothreads;


//public class ThreadDemo extends Thread {
	
	public class ThreadDemo implements Runnable
	{

	@Override
	public void run() 
	{
		//super.run();
		for (int i = 1; i <=5; i++) 
		{
			System.out.println("In thread "+i);
			try
			{
				Thread.sleep(1000);
			} 
			catch(InterruptedException e)
			{ e.printStackTrace();}
				
		}
	}



//	public void start() {
//		
//	}
	
//	public static void main(String[] args) 
//	{
//		
//		new ThreadDemo().start();
//		
//	}
	
	
	
}
