package com.cg.demothreads;

public class ThreadMain {

	public static void main(String[] args) {

//		ThreadDemo thread1 = new ThreadDemo();
//		thread1.start();
		
		ThreadDemo demo = new ThreadDemo();
		Thread thread = new Thread(demo);
		thread.start();
		
		for (int i = 1; i <=5; i++) 
		{
			System.out.println("Main: "+i);
			try
			{
				Thread.sleep(1000);
			} 
			catch(InterruptedException e)
			{ e.printStackTrace();}
//Main method is stopped till In thread is executed			
			//System.out.println(thread.isAlive());
			
			if(i==5)
			{
				try
				{
					thread.join();//It waits for a thread to die.
				} 
				catch(InterruptedException e)
				{ e.printStackTrace();}
			}
				
		}
		
		System.out.println(thread.isAlive());
	
	}

}
