package com.cg.dbconnection;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteDemo {

	public static void main(String[] args) {

		Connection con = DatabaseConnection.getConnection();
		 
		int empid;
		Scanner sc = new Scanner(System.in);
		 
		System.out.println("Enter empid: ");
		empid = sc.nextInt();
		String sql = "delete from employee where empid=?";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			
			 
			ps.setInt(1, empid);
			int rs = ps.executeUpdate();
			System.out.println("1 row Deleted");
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}