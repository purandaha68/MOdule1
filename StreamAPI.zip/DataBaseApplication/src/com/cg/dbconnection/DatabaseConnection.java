package com.cg.dbconnection;

 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

 
public class DatabaseConnection {
	
	public static Connection getConnection(){
		
		   Connection connection = null;
		   String url="jdbc:mysql://localhost:3306/tables";
		   String user="root";
		   String psd="9378";
		   
		   try {
			     Class.forName("com.mysql.jdbc.Driver");
			     System.out.println("Driver loaded");
			     connection = DriverManager.getConnection(url, user, psd);
			     System.out.println("Db Connected...");
		       } 
		   catch (ClassNotFoundException e) 
		         {
			   System.out.println("driver not loaded");
		         } catch (SQLException e) {
			     System.out.println(e.getMessage());
		}
		return connection;
	}
	
   public static void main(String[] args) 
   {   
	   getConnection();   
   }	

}
