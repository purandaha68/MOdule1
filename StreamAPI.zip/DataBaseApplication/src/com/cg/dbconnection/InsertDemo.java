package com.cg.dbconnection;

import java.sql.*;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class InsertDemo {

	public static void main(String[] args) {
		
		int empid;
		String empname;
		double salary;
		String joindate;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter empid: ");
		empid = sc.nextInt();
		System.out.println("Enter name: ");
		empname = sc.next();
		System.out.println("Enter joindate as (dd/MM/yyyy): ");
		joindate = sc.next();
		System.out.println("Enter salary: ");
		salary = sc.nextDouble();
	
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate doj = LocalDate.parse(joindate,formatter);
		
		Connection con = DatabaseConnection.getConnection();
		
		String sql = "insert into Employee(empid,empname,joindate,salary)" 
		              + "values(?,?,?,?)"; //dynamics SQl Query
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, empid);
			ps.setString(2, empname);
			Date date = Date.valueOf(doj);
			ps.setDate(3, date);
			ps.setDouble(4, salary);
			
			int rs = ps.executeUpdate();
			System.out.println("1 row inserted");
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		
	
	}
	
}
