package com.cg.dbconnection;

 
import java.time.LocalDate;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 

public class SelectDemo {

	public static void main(String[] args) {

		String sql ="select empname,empid,salary,joindate from employee where salary> ?";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter salary: ");
		double salary = sc.nextDouble();
		
		Connection con = DatabaseConnection.getConnection();
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setDouble(1, salary);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
			   String name = rs.getString("empname");	
			   int id = rs.getInt("empid");
			   double sal = rs.getDouble("salary");
			   Date date = rs.getDate("joindate");
			   LocalDate jd = date.toLocalDate();
			   
			   System.out.println(name+" "+id+" "+sal+" "+jd);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
	}

}
