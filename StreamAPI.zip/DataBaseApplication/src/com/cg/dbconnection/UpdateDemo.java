package com.cg.dbconnection;

 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateDemo {

	public static void main(String[] args) {

		Connection con = DatabaseConnection.getConnection();
		double salary;
		int empid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter salary: ");
		salary = sc.nextDouble();
		System.out.println("Enter empid: ");
		empid = sc.nextInt();
		String sql = "update employee set salary=? where empid=?";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setDouble(1, salary);
			ps.setInt(2, empid);
			int rs = ps.executeUpdate();
			System.out.println("1 row Updated");
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
